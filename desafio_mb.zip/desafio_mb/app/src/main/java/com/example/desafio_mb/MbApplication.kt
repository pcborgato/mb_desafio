package com.example.desafio_mb

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MbApplication : Application() {
    // You can add Application-level setup here if needed
}
